// Copyright (c) FRC Team 2363. All Rights Reserved.

#pragma once

#include <optional>
#include <tuple>

#include <frc/AddressableLED.h>
#include <frc/Compressor.h>
#include <frc/DigitalInput.h>
#include <frc/Joystick.h>
#include <frc/PneumaticsBase.h>
#include <frc/PneumaticsModuleType.h>
#include <frc/geometry/Rotation2d.h>
#include <frc2/command/CommandPtr.h>
#include <frc2/command/button/CommandXboxController.h>
#include <networktables/DoubleTopic.h>

#include "Constants.hpp"
#include "commands/autos/North2ConeHighChgstat.hpp"
#include "commands/autos/North2ConeHighPick1Cone.hpp"
#include "commands/autos/North3ConeLow.hpp"
#include "commands/autos/South2ConeHigh.hpp"
#include "subsystems/Superstructure.hpp"
#include "subsystems/SwerveDrive.hpp"
#include "util/TrajectoryManager.hpp"
#include "util/log/DoubleTelemetryEntry.hpp"

class RobotContainer {
 public:
  explicit RobotContainer(std::function<bool(void)> isDisabled);

  std::optional<frc2::Command*> GetAutonomousCommand();

  void UpdateTelemetry();

  void RunDisabled();

  void SuperstructurePeriodic();

  /**
   * Query the RIO's digital input pins to detect currently selected auto
   * routine index.
   *
   * @return the auto rotary switch index if detected, if not nullopt is
   * returned
   */
  std::optional<size_t> GetAutoSwitchIndex() const;

  void UpdateAutoSelected();
  void UpdateIsBlue();

  void LED();

  nt::DoublePublisher m_publisher;

 private:
  std::function<bool(void)> m_isDisabled;

  // Subsystems
  SwerveDrive m_drive;
  Superstructure m_superstructure;
  frc::Compressor m_compressor{ElectricalConstants::kPHPort,
                               frc::PneumaticsModuleType::REVPH};

  // Operator Interface (OI)
  frc::Joystick m_driver{OIConstants::kDriverControllerPort};
  frc2::CommandXboxController m_operator{OIConstants::kOperatorControllerPort};

  /**
   * Maps auto routines to auto rotary switch indices
   */
  enum class SelectedAuto {
    kNoAuto = 0,  // In case we can't find an auto that works with our alliance
    kNorth2ConeHighChgstat = 1,
    kSouth2ConeHigh = 2,
    kNorth2ConeHighPick1Cone = 3,
    kNorth3ConeLow = 4,
    kNumberOfAutos
  };

  SelectedAuto m_currentSelectedAuto = SelectedAuto::kNorth2ConeHighChgstat;
  bool m_isBlue = true;

  const std::array<frc::DigitalInput, 8> m_autoSwitch = {
      frc::DigitalInput(ElectricalConstants::kAutoSwitchPorts[0]),
      frc::DigitalInput(ElectricalConstants::kAutoSwitchPorts[1]),
      frc::DigitalInput(ElectricalConstants::kAutoSwitchPorts[2]),
      frc::DigitalInput(ElectricalConstants::kAutoSwitchPorts[3]),
      frc::DigitalInput(ElectricalConstants::kAutoSwitchPorts[4]),
      frc::DigitalInput(ElectricalConstants::kAutoSwitchPorts[5]),
      frc::DigitalInput(ElectricalConstants::kAutoSwitchPorts[6]),
      frc::DigitalInput(ElectricalConstants::kAutoSwitchPorts[7])};

  const frc::DigitalInput m_redBlueSwitch{
      ElectricalConstants::kRedBlueSwitchPort};

  North2ConeHighChgstat m_blueNorth2ConeHighChgstat;
  North2ConeHighPick1Cone m_blueNorth2ConeHighPick1Cone;
  South2ConeHigh m_blueSouth2ConeHigh;
  North3ConeLow m_blueNorth3ConeLow;

  North2ConeHighChgstat m_redNorth2ConeHighChgstat;
  North2ConeHighPick1Cone m_redNorth2ConeHighPick1Cone;
  South2ConeHigh m_redSouth2ConeHigh;
  North3ConeLow m_redNorth3ConeLow;

  void ConfigureBindings();

  DoubleTelemetryEntry m_oiDriverLeftXLog;
  DoubleTelemetryEntry m_oiDriverRightXLog;
  DoubleTelemetryEntry m_oiDriverRightYLog;
  DoubleTelemetryEntry m_autoSwitchIndexLog;

  frc::AddressableLED m_leds{0};
  std::array<frc::AddressableLED::LEDData, ElectricalConstants::kLEDBuffLength>
      m_ledBuffer;

  void ApplyLEDSingleStrip(
      const std::array<std::tuple<int, int, int>,
                       ElectricalConstants::kLEDStripLength>& stripBuffer,
      int stripID);

  void ClearLED();
  void GamePieceLED();
  void Yellow();
  void Green();
  void Purple();
  int m_previousSnakeIndex = -1;
  /// Used to test the order of the lights
  void SnakeBOI();
  void AutoLED();

 private:
  frc::Timer m_lastGamePieceIntake;
  bool m_lastIntake = false;
};
