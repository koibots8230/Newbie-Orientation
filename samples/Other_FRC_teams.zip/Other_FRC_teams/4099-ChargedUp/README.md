# ChargedUp-2023
[![Build](https://github.com/team4099/ChargedUp-2023/actions/workflows/gradle.yml/badge.svg?event=push)](https://github.com/team4099/ChargedUp-2023/blob/main/.github/workflows/gradle.yml)


![ChargedUp-2023](./assets/chargedup_logo.png)

# The Falcons (FRC 4099)
We are a school-based _FIRST&reg; Robotics Competition_ team from Poolesville High School, located in Poolesville, Maryland. Visit our website at [https://www.team4099.com/](https://www.team4099.com).
